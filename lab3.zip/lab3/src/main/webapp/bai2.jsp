<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>
<html>
<head>
<meta charset="UTF-8">
<title>Lab3</title>
</head>
<body>
<h1>Trang Index</h1>

    <ul>
        <li><a href="bai1lab3">Bài 1</a></li>
        <li><a href="bai2lab3">Bài 2</a></li>
        <li><a href="bai3lab3">Bài 3</a></li>
        <li><a href="bai4lab3">Bài 4</a></li>
    </ul>
    <hr>
    <style>
    /* CSS để định dạng bảng */
    .styled-table {
        border-collapse: collapse; /* Gộp các đường viền ô */
        margin: 25px 0;
        font-size: 0.9em;
        font-family: sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15); /* Thêm bóng đổ nhẹ */
    }

    /* Định dạng tiêu đề bảng */
    .styled-table thead tr {
        background-color: #009879; /* Màu nền xanh lục */
        color: #ffffff; /* Màu chữ trắng */
        text-align: left;
    }

    /* Định dạng các ô tiêu đề (th) và ô dữ liệu (td) */
    .styled-table th,
    .styled-table td {
        padding: 12px 15px;
        border: 1px solid #dddddd; /* Thêm đường viền mờ cho các ô */
    }

    /* Định dạng hàng dữ liệu */
    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }

    /* Tô màu xen kẽ cho các hàng (Stripe effect) */
    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3; /* Màu nền xám nhạt cho hàng chẵn */
    }

    /* Đổi màu hàng khi di chuột qua */
    .styled-table tbody tr:hover {
        background-color: #b2e4d9; /* Màu nền nhạt hơn khi di chuột */
        cursor: pointer;
    }

    /* Định dạng hàng cuối cùng */
    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid #009879; /* Đường viền đậm ở cuối */
    }
</style>

<table class="styled-table">
    <thead>
        <tr>
            <th>No.</th>
            <th>Id</th>
            <th>Name</th>
        </tr>
    </thead>
    <tbody>
        <c:forEach var="ct" items="${countries}" varStatus="vs">
            <tr>
                <td>${vs.count + 1}</td>
                <td>${ct.id}</td>
                <td>${ct.name}</td>
            </tr>
        </c:forEach>
    </tbody>
</table>
</body>
</html>