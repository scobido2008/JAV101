<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>
<html>
<head>
<meta charset="UTF-8">
<title>Lab3</title>
</head>
<body>
<h1>Trang Index</h1>

    <ul>
        <li><a href="bai1lab3">Bài 1</a></li>
        <li><a href="bai2lab3">Bài 2</a></li>
        <li><a href="bai3lab3">Bài 3</a></li>
        <li><a href="bai4lab3">Bài 4</a></li>
    </ul>
    <hr>
    <h3>Thông tin sản phẩm</h3>
  <ul>
    <li><b>Name:</b> ${item.name}</li>
    <li><b>Price:</b>
      <fmt:formatNumber value="${item.price}" pattern="#,###.00" />
    </li>
    <li><b>Date:</b>
      <fmt:formatDate value="${item.date}" pattern="MMM dd, yyyy" />
    </li>
  </ul>
</body>
</html>