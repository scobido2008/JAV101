<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lab3</title>
</head>
<body>
<h1>Trang Index</h1>

    <ul>
        <li><a href="bai1lab3">Bài 1</a></li>
        <li><a href="bai2lab3">Bài 2</a></li>
        <li><a href="bai3lab3">Bài 3</a></li>
        <li><a href="bai4lab3">Bài 4</a></li>
    </ul>
    <hr>
</body>
</html>