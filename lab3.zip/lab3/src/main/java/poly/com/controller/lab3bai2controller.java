package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.Country;
@WebServlet("/bai2lab3")
public class lab3bai2controller extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	List<Country> list = new ArrayList<>();
	list.add(new Country("VN", "Việt Nam"));
	list.add(new Country("US", "United States"));
	list.add(new Country("CN", "China"));
        req.setAttribute("countries", list);
	req.getRequestDispatcher("bai2.jsp").forward(req, resp);
}
}
