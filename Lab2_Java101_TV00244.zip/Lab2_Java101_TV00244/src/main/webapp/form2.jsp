<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Form & EL</title>
</head>
<body>
<form action="${pageContext.request.contextPath}/form/update2" method="post">
    Fullname:
    <input name="fullname" value="${user.fullname}" ${editable ? "" : "readonly"}><br>

    Gender:
    <input type="radio" name="gender" value="true" ${user.gender ? "checked" : ""}/> Male
    <input type="radio" name="gender" value="false" ${!user.gender ? "checked" : ""}/> Female<br>

    Country:
    <select name="country">
        <option value="VN" ${user.country == "VN" ? "selected" : ""}>Việt Nam</option>
        <option value="US" ${user.country == "US" ? "selected" : ""}>United States</option>
        <option value="CN" ${user.country == "CN" ? "selected" : ""}>China</option>
    </select><br>

    <button disabled>Create</button>
    <button>Update</button>
</form>
</body>
</html>
