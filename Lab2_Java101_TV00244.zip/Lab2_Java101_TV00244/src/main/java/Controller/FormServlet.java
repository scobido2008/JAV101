package Controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/form/update")
public class FormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Dữ liệu user ban đầu
        Map<String, Object> map = new HashMap<>();
        map.put("fullname", "Nguyễn Văn Tèo");
        map.put("gender", true);
        map.put("country", "VN");

        req.setAttribute("user", map);
        req.setAttribute("editable", true);

        // ⚙️ Đúng vị trí file JSP
        req.getRequestDispatcher("/form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Lấy dữ liệu người dùng nhập
        String fullname = req.getParameter("fullname");
        System.out.println("Fullname nhận được: " + fullname);

        // ⚙️ Trả lại form.jsp (đúng đường dẫn)
        req.getRequestDispatcher("/form.jsp").forward(req, resp);
    }
}
