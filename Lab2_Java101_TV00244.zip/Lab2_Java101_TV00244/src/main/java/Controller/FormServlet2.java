package Controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import Model.User;

@WebServlet("/form/update2")
public class FormServlet2 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Tạo đối tượng JavaBean
        User bean = new User();
        bean.setFullname("Nguyễn Văn Tèo");
        bean.setGender(true);
        bean.setCountry("VN");

        // Gửi bean sang JSP
        req.setAttribute("user", bean);
        req.setAttribute("editable", true);

        req.getRequestDispatcher("/form2.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Nhận dữ liệu từ form
        String fullname = req.getParameter("fullname");
        System.out.println("Fullname nhận được: " + fullname);

        req.getRequestDispatcher("/form2.jsp").forward(req, resp);
    }
}
